#pragma once

class Object {

public:



private:




protected:


};