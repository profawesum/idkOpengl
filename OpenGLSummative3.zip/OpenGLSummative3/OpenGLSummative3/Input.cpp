#include <iostream>
#include <freeglut.h>
#include <vector>
#include "Input.h"
#include "PlayerManager.h"
#include "glm.hpp"



using namespace std;
Input input2;

PlayerManager objectmanager2;

enum InputState
{
	INPUT_UP,
	INPUT_DOWN,
	INPUT_UP_FIRST,
	INPUT_DOWN_FIRST,
};

InputState KeyState[255];
InputState KeyState_S[255];



Input::Input()
{
}

Input::~Input()
{
}


Input copyinputclass()
{
	return(input2);
}
//checks to see if there is a key being pushed
bool Input::CheckKeyDown(int key)
{
	if (KeyState[key] == INPUT_DOWN)
	{
		return(true);
	}
	return(false);
}

//adds input delay
int Input::inputdelay(Input& input)
{
	if (input2.delay == 1)
	{
		input.delay++;
	}
	if (input2.delay == 2)
	{
		input.delay = 0;

	}
	return (input.delay);
}

bool Input::checkDownFirst(Input& input, unsigned char key)
{
	input.delay = inputdelay(input);

	if (input.delay > 2)
	{
		input.firstDown = false;
	}
	else
	{
		input.firstDown = true;
	}

	return (input.firstDown);
}
//sets a key to being down
void Input::KeyboardDown(unsigned char key, int x, int y)
{
	KeyState[key] = INPUT_DOWN;
	input2.delay = 1;
}
//sets a key to being up
void Input::KeyboardUp(unsigned char key, int x, int y)
{
	KeyState[key] = INPUT_UP;
	input2.delay = 2;
}

