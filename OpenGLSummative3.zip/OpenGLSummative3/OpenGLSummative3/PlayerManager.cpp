#include "PlayerManager.h"

Input input1;

PlayerManager::PlayerManager()
{

}

PlayerManager::~PlayerManager()
{

}
//get the player position
glm::vec3 PlayerManager::GetPlayerPos()
{
	return (playerPos);
}
//set the player position
void PlayerManager::SetPlayerPos(glm::vec3 temp)
{
	playerPos = temp;
}
//init the player
void PlayerManager::initializePlayerPos()
{
	playerPos = glm::vec3(0.0f, -0.2f, 0.0f);
}

void PlayerManager::movement(Audio1& audio2, GLfloat deltaTime, float screenW, float screenH)
{
	const float speed = 0.1f;
	glm::vec3 temp;
	temp = GetPlayerPos();
	//checks to see what input is given and moves the player according to inputted key
	if (input1.CheckKeyDown('s') == true){
		if (temp.z < 2.5f) {
			temp.z += speed * deltaTime;
			SetPlayerPos(temp);
		}
	}
	if (input1.CheckKeyDown('a') == true){
		if (temp.x > -3.5f)
		{
			temp.x -= speed * deltaTime;
			SetPlayerPos(temp);

		}
	}
	if (input1.CheckKeyDown('w') == true)
	{
		if (temp.z > -2.5f){
			temp.z -= speed * deltaTime;
			SetPlayerPos(temp);
		}
	}
	if (input1.CheckKeyDown('d') == true){
		if (temp.x < 2.5f){
			temp.x += speed * deltaTime;
			SetPlayerPos(temp);
		}
	}
}



