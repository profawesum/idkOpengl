#include <glew.h>
#include <freeglut.h>
#include <SOIL.h>
#include <iostream>
#include <time.h>
#include <vector>
#include <windows.h>
#include <cstdlib>
#include <fmod.hpp>
#include "ShaderLoader.h"

#include "glm.hpp"
#include "gtc/matrix_transform.hpp"
#include "gtc/type_ptr.hpp"
#include "Audio.h"
#include "Input.h"
#include "PlayerManager.h"
#include "Camera.h"
#include "Manager.h"
#include "TextLabel.h"
#include "EnemyManager.h"
#include "TextureLoader.h"
#include "MeshManager.h"
#include "CubeMap.h"
#include "Model.h"
#include "ModelMesh.h"

//using namespace
using namespace std;

//reference to shader loader
ShaderLoader m_shader;

//shader programs
GLuint program = NULL;
GLuint programBG = NULL;
GLuint programe1 = NULL;
GLuint programe2 = NULL;
GLuint programMap = NULL;

//various buffers
GLuint VBO;
GLuint VAO;
GLuint EBO;
//background buffers
GLuint VBObg;
GLuint VAObg;
GLuint EBObg;
//enemy buffers
GLuint VBOe1;
GLuint VAOe1;
GLuint EBOe1;

GLfloat currentTime;
GLfloat pasttime = 0;
GLfloat deltaTime;

int fps = 0;
int lives = 3;

//references to other classes
CubeMap cubemap;
LoadTexture TL;
Audio1 audio;
Input input;
camera camMain;
PlayerManager playermanager;
manager manager1;
EnemyManager enemymanager;
MeshManager meshmanager;

//text labels
TextLabel score;
TextLabel actualScore;
TextLabel menuLabel;
TextLabel subMenu;
TextLabel deathScreen;
TextLabel gameOverLabel;
TextLabel levelScreen;
TextLabel FPS;
TextLabel Lives;
TextLabel livesLeft;

//player, enemy and background/floor
GLuint player;
GLuint e1;
GLuint bg;

Model model;

float TotalScore = 0.0f;
bool startplay = false;
bool restartplay = true;
int menu = 0;
int gameRound = 1;
float rotO = 0.0f;

glm::vec3 rotationAxisZ = glm::vec3(1.0f, 0.0f, 0.0f);
float rotationAngle = 0;
glm::mat4 rotationZ = glm::rotate(glm::mat4(), glm::radians(rotationAngle), rotationAxisZ);


GLfloat vertices[] //player
{
	-1.0f, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,
	-1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 0.0f,
	1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 0.0f,
	1.0, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,

	-1.0, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	1.0, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	1.0, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	-1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	-1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	-1.0, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	0.0f, 0.5f, 0.0f,		0.0f, 1.0f, 1.0f,	0.5f, 0.0f,
};

GLuint indices[] =
{
	1, 4, 3,
	1, 3, 2,

	4, 12, 5,
	6, 12, 7,
	8, 12, 9,
	10, 12, 11,
};

GLfloat vertices2[] //bg
{	//pos                    //colour
	-1.0f,	-1.0f,	1.0f,    0.0f, 0.0f, 1.0f,		0.0f, 1.0f,//bot left
	1.0f,	-1.0f,	-1.0f,    1.0f, 0.0f, 0.0f,		1.0f, 0.0f,// top right
	-1.0f,	-1.0f,	-1.0f,    0.0f, 1.0f, 0.0f,		0.0f, 0.0f, //top left
	1.0f,	-1.0f,	1.0f,	 0.0f, 1.0f, 0.0f,		1.0f, 1.0f, //bot right
};

GLuint indices2[] =
{
	0,1,2,	//1 
	0,3,1,	//2
};

GLfloat vertices3[] //enemy
{	//pos                    //colour
	-0.5f,	-0.5f,	0.0f,    0.0f, 0.0f, 1.0f,		0.0f, 1.0f,//bot left
	0.5f,	0.5f,	0.0f,    1.0f, 0.0f, 0.0f,		1.0f, 0.0f,// top right
	-0.5f,	0.5f,	0.0f,    0.0f, 1.0f, 0.0f,		0.0f, 0.0f, //top left
	0.5f,	-0.5f,	0.0f,	 0.0f, 1.0f, 0.0f,		1.0f, 1.0f, //bot right
};

GLuint indices3[] =
{
	0,1,2,	//1 
	0,3,1,	//2
};

//manages the render of all objects
void Render()
{

	glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	//render the cubemap
	cubemap.Render();

	if (restartplay == true)
	{
		//if lives is = 0 then go to game over screen
		if (lives == 0) {
			menu = 2;
		}
		if (menu == 0)
		{
			input.inputdelay(input);
			//if p is pushed start the game
			if (input.CheckKeyDown('p') == true)
			{
				gameRound = 1;
				enemymanager.initSpeedandDir();
				playermanager.initializePlayerPos();
				enemymanager.initEPos();
				//enemymanager.initializeE2Pos();
				TotalScore = 0.0f;
				startplay = true;
				restartplay = false;
			}
			//if q is pushed then quit the game
			if (input.CheckKeyDown('q') == true)
			{
				glutLeaveMainLoop();
			}
			menuLabel.Render();
		}
		//game over screen
		else if (menu == 2)
		{
			//game over
			deathScreen.Render();
			actualScore.SetPosition(glm::vec2(-135.0f, 190.0f));
			actualScore.Render();
			actualScore.SetPosition(glm::vec2(-400.0f, 300.0f));
			//return to menu and reset lives
			if (input.CheckKeyDown('c') == true)
			{
				lives = 3;
				menu = 0;
			}

		}
		else if (menu == 3)
		{
			levelScreen.Render();
			actualScore.SetPosition(glm::vec2(-125.0f, 190.0f));
			actualScore.Render();
			actualScore.SetPosition(glm::vec2(-400.0f, 300.0f));
			//if the player dies and hits c continue the game
			if (input.CheckKeyDown('c') == true)
			{
				menu = 0;
				startplay = true;
				restartplay = false;
			}
		}

	}

	if (startplay == true)
	{
		//checks to see if it is a gameRound and the player has lives
		if (gameRound == 1 && lives > 0)
		{
#pragma region "bg"

			camMain.calculate(currentTime);
			glm::mat4 backProj_calc = camMain.MVP(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(2.0f, 2.0f, 2.0f), rotationZ);
			glm::mat4 backModel = camMain.Model(glm::vec3(0.0f, 45.0f, 0.0f), glm::vec3(2.0f, 2.0f, 2.0f), rotationZ);

			glUseProgram(programBG);

			GLuint mvpLoc2 = glGetUniformLocation(programBG, "proj_calc");
			glUniformMatrix4fv(mvpLoc2, 1, GL_FALSE, glm::value_ptr(backProj_calc));

			GLuint backModelLoc = glGetUniformLocation(program, "model");
			glUniformMatrix4fv(backModelLoc, 1, GL_FALSE, glm::value_ptr(backModel));

			glUniform1i(glGetUniformLocation(programe1, "skybox"), 0);
			glBindTexture(GL_TEXTURE_CUBE_MAP, cubemap.textureID);

			glBindVertexArray(VAObg);
			glBindTexture(GL_TEXTURE_2D, bg);
			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
			glBindVertexArray(0);
			glUseProgram(0);

#pragma endregion 

#pragma region "player"
			glUseProgram(program);

			playermanager.movement(audio, deltaTime, manager1.GetSCREEN_W(), manager1.GetSCREEN_H());
			camMain.calculate(currentTime);
			glm::vec3 objPosition = glm::vec3(0.5f, 0.5f, 0.0f);
			objPosition += playermanager.GetPlayerPos();
			glm::vec3 objscale = glm::vec3(0.5f, 0.5f, 1.0f);

			glm::mat4 mvp = camMain.MVP(objPosition, objscale, rotationZ);
			glm::mat4 model = camMain.Model(objPosition, objscale, rotationZ);

			GLuint mvpLoc = glGetUniformLocation(program, "mvp");
			glUniformMatrix4fv(mvpLoc, 1, GL_FALSE, glm::value_ptr(mvp));

			GLuint modelLoc = glGetUniformLocation(program, "model");
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

			GLint currentTimeLoc = glGetUniformLocation(program, "currentTime");//gluint?
			glUniform1f(currentTimeLoc, currentTime);

			glUniform1i(glGetUniformLocation(program, "skybox"), 0);
			glBindTexture(GL_TEXTURE_CUBE_MAP, cubemap.programMap);

			glBindVertexArray(VAO);

			glBindTexture(GL_TEXTURE_2D, player);

			glDrawElements(GL_TRIANGLES, sizeof(indices), GL_UNSIGNED_INT, 0);
			glBindVertexArray(0);
			glUseProgram(0);
#pragma endregion 


#pragma region "e1"

			enemymanager.Emovement(deltaTime, manager1.GetSCREEN_W(), manager1.GetSCREEN_H(), audio, 1);
			camMain.calculate(currentTime);

			glm::vec3 e1pos = glm::vec3(0.0f, 0.0f, 1.0f);
			e1pos += enemymanager.GetEPos();
			glm::vec3 e1scale = glm::vec3(1.0f, 1.0f, 1.0f);

			glm::mat4 Proj_calc = camMain.MVP(e1pos, e1scale, rotationZ);
			glm::mat4 enemyModel = camMain.Model(e1pos, e1scale, rotationZ);

			glUseProgram(programe1);

			GLuint mvpLoc3 = glGetUniformLocation(programe1, "proj_calc");
			glUniformMatrix4fv(mvpLoc3, 1, GL_FALSE, glm::value_ptr(Proj_calc));

			GLuint eModelLoc = glGetUniformLocation(program, "model");
			glUniformMatrix4fv(eModelLoc, 1, GL_FALSE, glm::value_ptr(enemyModel));

			glBindVertexArray(VAOe1);
			glBindTexture(GL_TEXTURE_2D, e1);

			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
			glBindVertexArray(0);
			glUseProgram(0);

#pragma endregion 

			//check for collision
			glm::vec4 playerbox(objPosition.z, objPosition.z - objscale.z, objPosition.x, objPosition.x + objscale.x);// + objscale.x //up down left right
			glm::vec4 enemybox(e1pos.z, e1pos.z - e1scale.z, e1pos.x, e1pos.x + e1scale.x);// + e1scale.x
			bool collision = false;
			collision = enemymanager.checkCollision(playerbox, enemybox);
			//if collision is true
			if (collision == true)
			{
				//play sound and reset the round
				audio.playSound(2);
				enemymanager.initSpeedandDir();
				playermanager.initializePlayerPos();
				enemymanager.initEPos();
				gameRound = 1;
				//deduct a life
				lives -= 1;
				startplay = false;
				restartplay = true;
				menu = 3;
			}
			//display the score and lives
			TotalScore = TotalScore + deltaTime;
			int displayScore = static_cast<int>(TotalScore);
			actualScore.SetText(to_string(displayScore));
			score.Render();
			actualScore.Render();
			Lives.Render();
			livesLeft.SetText(to_string(lives));
			livesLeft.Render();
		}
	}
	//set the fps
	FPS.SetText(to_string(fps));
	FPS.Render();
	glBindVertexArray(0);
	glUseProgram(0);
	//render the pug model
	model.Render();

	glutSwapBuffers();
}

//update, runs each frame
void Update()
{
	if (input.CheckKeyDown('m') == true)
	{
		//if the player is in the game and hits m, go to game over screen
		if (startplay == true)
		{
			audio.playSound(2);
			enemymanager.initSpeedandDir();
			playermanager.initializePlayerPos();
			enemymanager.initEPos();
			gameRound = 3;
			startplay = false;
			restartplay = true;
			menu = 2;
		}
	}
	//update audio
	audio.update();

	currentCamera = &camMain;
	cubemap.Update();
	currentTime = (GLfloat)glutGet(GLUT_ELAPSED_TIME);
	deltaTime = (currentTime - pasttime)* 0.1f;
	pasttime = currentTime;
	//get the fps
	fps = manager1.FPS(deltaTime);

	glutPostRedisplay();

}

//main loop, entry point
int main(int argc, char **argv)
{
	//set the screen dimensions
	manager1.SetScreenDimentions(1, 1280);
	manager1.SetScreenDimentions(2, 720);
	srand(static_cast <unsigned> (time(0)));
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(50, 50);


	glutInitWindowSize(static_cast<int>(manager1.GetSCREEN_W()), static_cast<int>(manager1.GetSCREEN_H()));
	glutCreateWindow("IDK ANYMORE, WHAT AM I DOING ?!?!?!?!?!?!?");
	//glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK)
	{
		cout << "somthin wrong cheif" << endl;
		system("pause");
	}

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	/*glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glFrontFace(GL_CCW);*/

	//set the camera to projection
	camMain.SetProj(glm::perspective(45.0f, (float)manager1.GetSCREEN_W() / (float)manager1.GetSCREEN_H(), 0.1f, 10000.0f));

	glClearColor(1.0f, 0.3f, 0.3f, 1.0f);
	//create the programs
	program = ShaderLoader::CreateProgram("shader.vs", "Assets/shader/BlingPhongShader.fs");
	programBG = ShaderLoader::CreateProgram("Assets/shader/Reflection.vs", "Assets/shader/Reflection.fs");
	programe1 = ShaderLoader::CreateProgram("backG.vs", "Assets/shader/BlingPhongShader.fs");
	programe2 = ShaderLoader::CreateProgram("backG.vs", "Assets/shader/BlingPhongShader.fs");
	programMap = ShaderLoader::CreateProgram("CubeMap.vs", "CubeMap.fs");
	//set the cubemap program
	cubemap.setProgram(programMap);

#pragma region "text"
	//create text labels
	score = TextLabel(manager1, "score:", "Assets/fonts/comic.ttf", glm::vec2(-600.0f, 300.0f));
	actualScore = TextLabel(manager1, "", "Assets/fonts/comic.ttf", glm::vec2(-400.0f, 300.0f));
	menuLabel = TextLabel(manager1, R"(IDK ANYMORE 
P to Play 
Q to Quit )", "Assets/fonts/comic.ttf", glm::vec2(-600.0f, 300.0f));

	deathScreen = TextLabel(manager1, R"(GAME OVER

Final Score:
Press c to Return to Menu)", "Assets/fonts/comic.ttf", glm::vec2(-600.0f, 300.0f));

	levelScreen = TextLabel(manager1, R"(You Died

your current score is 
Press c to Continue)", "Assets/fonts/comic.ttf", glm::vec2(-600.0f, 300.0f));
	FPS = TextLabel(manager1, "0", "Assets/fonts/comic.ttf", glm::vec2(550.0f, 300.0f)/*glm::vec3(1.0f, 1.0f, 1.0f), 0.5f*/);
	Lives = TextLabel(manager1, "Lives: ", "Assets/fonts/comic.ttf", glm::vec2(-600.0f, 250.0f));
	livesLeft = TextLabel(manager1, " ", "Assets/fonts/comic.ttf", glm::vec2(-400.0f, 250.0f));

#pragma endregion 
	//create cubemap, using the folder named yokahama
	cubemap.Create("yokahama");

	//create the player
#pragma region "player"

	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);

	glGenBuffers(1, &EBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	glGenBuffers(1, &VBO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, (8 * (sizeof(GLfloat))), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, (8 * (sizeof(GLfloat))), (GLvoid*)(3 * (sizeof(GLfloat))));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, (8 * (sizeof(GLfloat))), (GLvoid*)(6 * (sizeof(GLfloat))));
	glEnableVertexAttribArray(2);

	glActiveTexture(GL_TEXTURE0);
	player = TL.loadTexture("Assets/Textures/spaceShips_009.png");
	glBindTexture(GL_TEXTURE_2D, player);
	glUniform1i(glGetUniformLocation(program, "tex"), 0);


#pragma endregion 

	//create the background
#pragma region "bg"

	glGenVertexArrays(1, &VAObg);
	glBindVertexArray(VAObg);

	glGenBuffers(1, &EBObg);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBObg);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices2), indices2, GL_STATIC_DRAW);

	glGenBuffers(1, &VBObg);
	glBindBuffer(GL_ARRAY_BUFFER, VBObg);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices2), vertices2, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glActiveTexture(GL_TEXTURE2);
	bg = TL.loadTexture("Assets/Textures/spaceBuilding_009.png");
	glBindTexture(GL_TEXTURE_2D, bg);
	glUniform1i(glGetUniformLocation(programBG, "tex"), 2);

#pragma endregion 

	//create the enemy
#pragma region "enemy1"

	glGenVertexArrays(1, &VAOe1);
	glBindVertexArray(VAOe1);

	glGenBuffers(1, &EBOe1);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOe1);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices3), indices3, GL_STATIC_DRAW);

	glGenBuffers(1, &VBOe1);
	glBindBuffer(GL_ARRAY_BUFFER, VBOe1);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices3), vertices3, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glActiveTexture(GL_TEXTURE3);
	e1 = TL.loadTexture("Assets/Textures/spaceShips_007.png");
	glBindTexture(GL_TEXTURE_2D, e1);
	glUniform1i(glGetUniformLocation(program, "tex"), 3);

#pragma endregion 
	//init camera
	camMain.initCamera();
	//init the audio and load some sounds
	audio.AudioInit();
	audio.Create("Assets/sounds/WhoTaughtYouHowToHate.mp3", 1);
	audio.Create("Assets/Sounds/Thump.wav", 2);
	//play the background track
	audio.playSound(1);

	//create the model
	model = Model::Model("Assets/models/pug/dog 1.obj", &camMain);


	glutDisplayFunc(Render);
	glutIdleFunc(Update);

	glutKeyboardFunc(Input::KeyboardDown);
	glutKeyboardUpFunc(Input::KeyboardUp);

	glutMainLoop();

	return 0;
}
