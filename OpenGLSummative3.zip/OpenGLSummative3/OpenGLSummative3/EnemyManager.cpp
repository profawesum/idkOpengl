#include "EnemyManager.h"

EnemyManager::EnemyManager()
{
}

EnemyManager::~EnemyManager()
{
}
//get enemy position
glm::vec3 EnemyManager::GetEPos()
{
	return (ePos);
}
//set the enemy position
void EnemyManager::SetEPos(glm::vec3 temp)
{
	ePos = temp;
}
//init the enemy
void EnemyManager::initEPos()
{
	ePos = glm::vec3(0.0f, 0.0f, 0.0f);
}
//get a random value
glm::vec2 EnemyManager::Getrandxy()
{
	return (randxy);
}
//set the random value
void EnemyManager::Setrandxy(glm::vec2)
{
	randxy.x = (0.5f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (2.0f - 0.5f))));
	randxy.y = (0.5f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (2.0f - 0.5f))));

}
//init the speed and direction of the enemy
void EnemyManager::initSpeedandDir()
{
	speed = 0.001f;
	dir = 1;
	dir2 = 1;
	Setrandxy(randxy);

}
//actual enemy movement
void EnemyManager::Emovement(GLfloat deltaTime, float ScreenW, float screenH, Audio1& audio2, int type)
{

	speed += 0.00001f * deltaTime;
	glm::vec3 temp;
	temp = GetEPos();

	//wd
	if (type == 1 && (dir == 1))
	{
		temp.z += speed * deltaTime;
		temp.x += speed * deltaTime;
		SetEPos(temp);
		if (temp.z > 1.0f)
		{
			dir = 4;
			audio2.playSound(2);

		}
		if (temp.x > 1.0f)
		{
			dir = 2;
			audio2.playSound(2);
		}
	}
	//aw
	if (type == 1 && dir == 2)
	{
		temp.x -= speed * deltaTime;
		temp.z += speed * deltaTime;
		SetEPos(temp);
		if (temp.x < (-1.0f))
		{
			dir = 1;
			audio2.playSound(2);

		}
		if (temp.z >(1.0f))
		{
			dir = 3;
			audio2.playSound(2);

		}
	}
	//sa

	if (type == 1 && dir == 3)
	{
		temp.z -= speed * deltaTime;
		temp.x -= speed * deltaTime;
		SetEPos(temp);
		if (temp.z < (-1.0f))
		{
			dir = 2;
			audio2.playSound(2);
		}
		if (temp.x < (-1.0f))
		{
			dir = 4;
			audio2.playSound(2);
		}
	}
	//ds

	if (type == 1 && dir == 4)
	{
		temp.x += speed * deltaTime;
		temp.z -= speed * deltaTime;
		SetEPos(temp);
		if (temp.x > (1.0f))
		{
			dir = 3;
			audio2.playSound(2);
		}
		if (temp.z < (-1.0f))
		{
			dir = 1;
			audio2.playSound(2);
		}
	}

}
//checks the collision between enemy and player
bool EnemyManager::checkCollision(glm::vec4 box1, glm::vec4 box2)
{
	bool collision = false;
	if ((box1.x > box2.x) && (box1.y < box2.x))
	{
		if ((box1.z < box2.z) && (box1.w > box2.z))
		{
			collision = true;
		}
		if ((box1.z < box2.w) && (box1.w > box2.w))
		{
			collision = true;
		}
	}
	if ((box1.x > box2.y) && (box1.y < box2.y))
	{
		if ((box1.z < box2.z) && (box1.w > box2.z))
		{
			collision = true;
		}
		if ((box1.z < box2.w) && (box1.w > box2.w))
		{
			collision = true;
		}
	}
	return(collision);
}